// src/components/shared/MenuInferior.tsx
// COMPONENTE REMOVIDO — navegação inferior foi consolidada em src/app/(app)/layout.tsx
// Este arquivo é mantido apenas para compatibilidade com imports existentes.
// Se nenhum arquivo importa este componente, pode ser deletado com segurança.

export function MenuInferior() {
  return null
}
