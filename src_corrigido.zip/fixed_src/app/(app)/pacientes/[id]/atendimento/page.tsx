// src/app/(app)/pacientes/[id]/atendimento/page.tsx
// Este segmento não tem uma página própria — redireciona para a ficha do paciente
import { redirect } from 'next/navigation'

interface Props {
  params: { id: string }
}

export default function AtendimentoIndexPage({ params }: Props) {
  redirect(`/pacientes/${params.id}`)
}
