// scripts/migrar.mjs
// Migração: sistema antigo → Consultório Hoffmann
//
// Como usar:
//   1. Preencha as 4 variáveis de ambiente abaixo
//   2. Execute: node scripts/migrar.mjs
//   3. Acompanhe o log — é seguro rodar mais de uma vez (idempotente por CPF/ID)

import { createClient } from '@supabase/supabase-js'

// ─── CONFIGURE AQUI ───────────────────────────────────────────────────────────

const ANTIGO_URL    = 'https://czpjldwummbpovyedujt.supabase.co'        // URL do projeto ANTIGO
const ANTIGO_KEY    = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN6cGpsZHd1bW1icG92eWVkdWp0Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2OTQ2Mzk3MSwiZXhwIjoyMDg1MDM5OTcxfQ.pypKO53ezhxwl9kXX_y18HarF8IxF6pPki5GR6cbfXs' // service_role key do ANTIGO
const NOVO_URL      = 'https://ubrqjtontylxovfvcbkh.supabase.co'        // URL do projeto NOVO
const NOVO_KEY      = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVicnFqdG9udHlseG92ZnZjYmtoIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MTcwNjIyNSwiZXhwIjoyMDg3MjgyMjI1fQ.ygt8Mwt74ig9HJvr_pXVjy9IH1IbEgOFR53nYMOItvU' // service_role key do NOVO
const NOVA_CLINICA_ID = '060f4f91-0836-4a62-add6-ad9d03d6939a' // SELECT id FROM clinicas LIMIT 1

// ─────────────────────────────────────────────────────────────────────────────

const antigo = createClient(ANTIGO_URL, ANTIGO_KEY)
const novo   = createClient(NOVO_URL,   NOVO_KEY,  { auth: { persistSession: false } })

let contadores = {
  pacientes: { ok: 0, skip: 0, erro: 0 },
  atendimentos: { ok: 0, skip: 0, erro: 0 },
  orcamentos: { ok: 0, skip: 0, erro: 0 },
  orcamento_itens: { ok: 0, skip: 0, erro: 0 },
  radiografias: { ok: 0, skip: 0, erro: 0 },
  pagamentos: { ok: 0, skip: 0, erro: 0 },
}

function log(emoji, msg) { console.log(`${emoji}  ${msg}`) }
function ok(tabela)      { contadores[tabela].ok++ }
function skip(tabela)    { contadores[tabela].skip++ }
function erro(tabela, e) { contadores[tabela].erro++; console.error(`   ❌ ${e}`) }

// ─── Mapa de IDs antigo → novo ────────────────────────────────────────────────
const mapaPacientes    = new Map() // antigoId → novoId
const mapaAtendimentos = new Map()
const mapaOrcamentos   = new Map()

// ─── 1. PACIENTES ─────────────────────────────────────────────────────────────
async function migrarPacientes() {
  log('👥', 'Migrando pacientes...')

  const { data: pacientesAntigos } = await antigo
    .from('pacientes')
    .select('*')
    .eq('ativo', true)
    .order('created_at')

  if (!pacientesAntigos?.length) { log('⚠️', 'Nenhum paciente encontrado'); return }
  log('📋', `${pacientesAntigos.length} pacientes encontrados`)

  for (const p of pacientesAntigos) {
    // Verificar se já existe pelo CPF (evita duplicatas em re-execução)
    if (p.cpf) {
      const { data: existe } = await novo
        .from('pacientes')
        .select('id')
        .eq('cpf', p.cpf)
        .eq('clinica_id', NOVA_CLINICA_ID)
        .maybeSingle()

      if (existe) {
        mapaPacientes.set(p.id, existe.id)
        skip('pacientes')
        continue
      }
    }

    // Montar endereço completo
    const enderecoPartes = [p.endereco, p.numero, p.complemento, p.bairro, p.cidade, p.uf]
      .filter(Boolean).join(', ')

    const { data: novo_paciente, error } = await novo
      .from('pacientes')
      .insert({
        clinica_id:      NOVA_CLINICA_ID,
        nome:            p.nome,
        cpf:             p.cpf   || null,
        telefone:        p.telefone || null,
        email:           p.email || null,
        data_nascimento: p.data_nascimento || null,
        observacoes:     [p.observacoes, p.responsavel_legal ? `Responsável: ${p.responsavel_legal}` : null]
                           .filter(Boolean).join('\n') || null,
        created_at:      p.created_at,
      })
      .select('id')
      .single()

    if (error) { erro('pacientes', `${p.nome}: ${error.message}`); continue }

    mapaPacientes.set(p.id, novo_paciente.id)
    ok('pacientes')
    log('✅', `Paciente: ${p.nome}`)
  }
}

// ─── 2. ATENDIMENTOS ──────────────────────────────────────────────────────────
async function migrarAtendimentos() {
  log('🦷', 'Migrando atendimentos...')

  const { data: atendimentosAntigos } = await antigo
    .from('atendimentos')
    .select('*')
    .order('data_atendimento')

  if (!atendimentosAntigos?.length) { log('⚠️', 'Nenhum atendimento encontrado'); return }
  log('📋', `${atendimentosAntigos.length} atendimentos encontrados`)

  for (const a of atendimentosAntigos) {
    const novoPacienteId = mapaPacientes.get(a.paciente_id)
    if (!novoPacienteId) {
      skip('atendimentos')
      continue // paciente não migrado (inativo)
    }

    // Verificar se já existe (idempotência por paciente + data + procedimento)
    const dataStr = a.data_atendimento?.split('T')[0]
    const { data: existe } = await novo
      .from('atendimentos')
      .select('id')
      .eq('paciente_id', novoPacienteId)
      .eq('clinica_id', NOVA_CLINICA_ID)
      .eq('data_atendimento', dataStr)
      .eq('procedimento_nome', a.procedimento_nome ?? '')
      .maybeSingle()

    if (existe) {
      mapaAtendimentos.set(a.id, existe.id)
      skip('atendimentos')
      continue
    }

    // Determinar valor final
    const valorFinal = a.valor_final ?? a.valor ?? null

    const { data: novoAtend, error } = await novo
      .from('atendimentos')
      .insert({
        clinica_id:       NOVA_CLINICA_ID,
        paciente_id:      novoPacienteId,
        data_atendimento: dataStr,
        procedimento_nome: a.procedimento_nome || null,
        descricao:        [a.descricao, a.observacoes, a.diagnostico]
                            .filter(Boolean).join(' | ') || null,
        valor_total:      valorFinal,
        created_at:       a.created_at,
      })
      .select('id')
      .single()

    if (error) { erro('atendimentos', `${a.id}: ${error.message}`); continue }

    mapaAtendimentos.set(a.id, novoAtend.id)
    ok('atendimentos')
  }
}

// ─── 3. ORÇAMENTOS ────────────────────────────────────────────────────────────
async function migrarOrcamentos() {
  log('📋', 'Migrando orçamentos...')

  const { data: orcsAntigos } = await antigo
    .from('orcamentos')
    .select('*')
    .order('created_at')

  if (!orcsAntigos?.length) { log('⚠️', 'Nenhum orçamento encontrado'); return }
  log('📋', `${orcsAntigos.length} orçamentos encontrados`)

  // Buscar itens de todos os orçamentos de uma vez
  const { data: todosItens } = await antigo
    .from('orcamento_itens')
    .select('*')
    .in('orcamento_id', orcsAntigos.map(o => o.id))

  const itensPorOrc = {}
  for (const item of (todosItens ?? [])) {
    if (!itensPorOrc[item.orcamento_id]) itensPorOrc[item.orcamento_id] = []
    itensPorOrc[item.orcamento_id].push(item)
  }

  for (const o of orcsAntigos) {
    const novoPacienteId = mapaPacientes.get(o.paciente_id)
    if (!novoPacienteId) { skip('orcamentos'); continue }

    // Mapear status
    const statusMap = {
      'aprovado': 'aprovado',
      'aceito':   'aprovado',
      'recusado': 'recusado',
      'cancelado': 'recusado',
      'pendente': 'pendente',
      'aguardando': 'pendente',
    }
    const novoStatus = statusMap[o.status?.toLowerCase()] ?? 'pendente'

    const { data: novoOrc, error } = await novo
      .from('orcamentos')
      .insert({
        clinica_id:  NOVA_CLINICA_ID,
        paciente_id: novoPacienteId,
        status:      novoStatus,
        observacoes: o.observacoes || o.condicoes_pagamento || null,
        created_at:  o.created_at,
      })
      .select('id')
      .single()

    if (error) { erro('orcamentos', `${o.id}: ${error.message}`); continue }

    mapaOrcamentos.set(o.id, novoOrc.id)
    ok('orcamentos')

    // Migrar itens do orçamento
    const itens = itensPorOrc[o.id] ?? []
    for (const item of itens) {
      const { error: errItem } = await novo
        .from('orcamento_itens')
        .insert({
          orcamento_id:      novoOrc.id,
          procedimento_nome: item.descricao || 'Procedimento',
          valor:             item.valor_total ?? item.valor_unitario ?? 0,
        })
      if (errItem) erro('orcamento_itens', errItem.message)
      else ok('orcamento_itens')
    }
  }
}

// ─── 4. PAGAMENTOS (tabela pagamentos do sistema antigo) ──────────────────────
async function migrarPagamentos() {
  log('💰', 'Migrando pagamentos...')

  const { data: pagamentosAntigos } = await antigo
    .from('pagamentos')
    .select('*')
    .order('data_pagamento')

  if (!pagamentosAntigos?.length) { log('⚠️', 'Nenhum pagamento encontrado'); return }
  log('📋', `${pagamentosAntigos.length} pagamentos encontrados`)

  // Agrupar pagamentos por paciente para criar lançamentos
  const pgtosPorPaciente = {}
  for (const pg of pagamentosAntigos) {
    if (!pgtosPorPaciente[pg.paciente_id]) pgtosPorPaciente[pg.paciente_id] = []
    pgtosPorPaciente[pg.paciente_id].push(pg)
  }

  for (const [antigoPackId, pgtos] of Object.entries(pgtosPorPaciente)) {
    const novoPacienteId = mapaPacientes.get(antigoPackId)
    if (!novoPacienteId) { skip('pagamentos'); continue }

    // Cada pagamento individual vira um lançamento + parcela paga
    for (const pg of pgtos) {
      const valor = Number(pg.valor ?? 0)
      if (valor <= 0) { skip('pagamentos'); continue }

      const dataStr = pg.data_pagamento?.split('T')[0] ?? new Date().toISOString().split('T')[0]

      // Criar lançamento de receita
      const descricao = `Pagamento migrado${pg.observacoes ? ' – ' + pg.observacoes : ''}`
      const { data: lanc, error: errLanc } = await novo
        .from('financeiro_lancamentos')
        .insert({
          clinica_id:   NOVA_CLINICA_ID,
          paciente_id:  novoPacienteId,
          tipo:         'receita',
          descricao:    descricao,
          valor_total:  valor,
          num_parcelas: 1,
          created_at:   pg.created_at,
        })
        .select('id')
        .single()

      if (errLanc) { erro('pagamentos', errLanc.message); continue }

      // Criar parcela já paga
      const { error: errParcela } = await novo
        .from('financeiro_parcelas')
        .insert({
          lancamento_id:   lanc.id,
          clinica_id:      NOVA_CLINICA_ID,
          numero:          1,
          valor:           valor,
          valor_pago:      valor,
          data_vencimento: dataStr,
          data_pagamento:  dataStr,
          status:          'pago',
        })

      if (errParcela) { erro('pagamentos', errParcela.message); continue }
      ok('pagamentos')
    }
  }
}

// ─── 5. RADIOGRAFIAS ──────────────────────────────────────────────────────────
async function migrarRadiografias() {
  log('🔬', 'Migrando radiografias...')

  const { data: rxAntigos } = await antigo
    .from('radiografias')
    .select('*')
    .order('created_at')

  if (!rxAntigos?.length) { log('⚠️', 'Nenhuma radiografia encontrada'); return }
  log('📋', `${rxAntigos.length} radiografias encontradas`)

  for (const rx of rxAntigos) {
    const novoPacienteId = mapaPacientes.get(rx.paciente_id)
    if (!novoPacienteId) { skip('radiografias'); continue }

    // CORREÇÃO: Baixar o arquivo diretamente usando a service_role
    // Isso ignora se o bucket é público ou privado
    const { data: blob, error: downloadError } = await antigo.storage
      .from('radiografias')
      .download(rx.arquivo_path)

    if (downloadError || !blob) {
      erro('radiografias', `Falha ao baixar ${rx.arquivo_path}: ${downloadError?.message}`)
      continue
    }

    // Converter Blob para Buffer (necessário para o upload no Node.js)
    const arrayBuffer = await blob.arrayBuffer()
    const fileBuffer = Buffer.from(arrayBuffer)

    // Determinar extensão
    const ext = rx.arquivo_path.split('.').pop() ?? 'jpg'
    const nomeArquivo = `${NOVA_CLINICA_ID}/${novoPacienteId}/${Date.now()}_${rx.id.slice(0,8)}.${ext}`

    // Upload no storage novo
    const { error: errUpload } = await novo.storage
      .from('radiografias')
      .upload(nomeArquivo, fileBuffer, {
        contentType: `image/${ext === 'pdf' ? 'pdf' : ext}`,
        upsert: false,
      })

    if (errUpload) { erro('radiografias', `Upload ${nomeArquivo}: ${errUpload.message}`); continue }

    // Registrar no banco novo
    const { error: errDb } = await novo
      .from('radiografias')
      .insert({
        clinica_id:  NOVA_CLINICA_ID,
        paciente_id: novoPacienteId,
        arquivo_url: nomeArquivo,
        anotacao:    rx.titulo || rx.descricao || rx.observacoes || null,
        created_at:  rx.created_at,
      })

    if (errDb) { erro('radiografias', errDb.message); continue }
    ok('radiografias')
    log('🖼️', `Radiografia: ${rx.titulo ?? rx.arquivo_path}`)
  }
}
// ─── EXECUÇÃO ─────────────────────────────────────────────────────────────────

async function main() {
  console.log('\n🚀 Iniciando migração...\n')
  const inicio = Date.now()

  await migrarPacientes()
  console.log('')
  await migrarAtendimentos()
  console.log('')
  await migrarOrcamentos()
  console.log('')
  await migrarPagamentos()
  console.log('')
  await migrarRadiografias()

  const duracao = ((Date.now() - inicio) / 1000).toFixed(1)

  console.log('\n' + '─'.repeat(50))
  console.log('📊 RESULTADO FINAL')
  console.log('─'.repeat(50))
  for (const [tabela, c] of Object.entries(contadores)) {
    const total = c.ok + c.skip + c.erro
    if (total === 0) continue
    console.log(`${tabela.padEnd(20)} ✅ ${String(c.ok).padStart(3)} migrados  ⏭️  ${String(c.skip).padStart(3)} já existiam  ❌ ${String(c.erro).padStart(3)} erros`)
  }
  console.log('─'.repeat(50))
  console.log(`⏱️  Tempo total: ${duracao}s\n`)
}

main().catch(console.error)
